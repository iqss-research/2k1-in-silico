#ifndef MATRIX_AbstrINDEX_H
#define MATRIX_AbstrINDEX_H

#include "Mutils.h"

SEXP Matrix_rle_i(SEXP x_, SEXP force_);
SEXP Matrix_rle_d(SEXP x_, SEXP force_);

#endif

