#ifndef MATRIX_LGCMATRIX_H
#define MATRIX_LGCMATRIX_H

#include "Mutils.h"

SEXP lgC_to_matrix(SEXP x);
SEXP ngC_to_matrix(SEXP x);

#endif
