"auuc" <-
structure(list(Commerce = c(446, 937, 311, 49), Arts = c(895, 
1834, 805, 157), SciEng = c(496, 994, 430, 62), Law = c(170, 
246, 95, 15), Medicine = c(184, 198, 48, 9)), .Names = c("Commerce", 
"Arts", "SciEng", "Law", "Medicine"), row.names = c("SES1", "SES2", 
"SES3", "SES4"), class = "data.frame")
