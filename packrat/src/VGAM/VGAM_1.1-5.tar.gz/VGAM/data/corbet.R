corbet <-
structure(list(ofreq = 1:24, species = c(118, 74, 44, 24, 29, 
22, 20, 19, 20, 15, 12, 14, 6, 12, 6, 9, 9, 6, 10, 10, 11, 5, 
3, 3)), .Names = c("ofreq", "species"), row.names = c(NA, -24L
), class = "data.frame")
