library(testthat)
library(bslib)

test_check("bslib")
