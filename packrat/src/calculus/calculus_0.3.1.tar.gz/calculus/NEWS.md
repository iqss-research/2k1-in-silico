# calculus 0.3.1

- fix CRAN check
- fix JSS pre-review comments

# calculus 0.3.0

- __breaking changes__: restructuring of package
- added Ordinary Differential Equations
- added vignettes

# calculus 0.2.2

- added variables transformation in Hermite polynomials

# calculus 0.2.1

- removed startup message

# calculus 0.2.0

- __breaking changes__: rewrite `integral()`; interfacing the function to the `cubature` package for efficient integration in C 
- __breaking changes__: option `auto.wrap` renamed `calculus.auto.wrap`

# calculus 0.1.1

- fix ambiguous call to pow() C++

# calculus 0.1.0

- initial release