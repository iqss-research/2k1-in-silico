library(testthat)
library(calculus)

test_check("calculus")
