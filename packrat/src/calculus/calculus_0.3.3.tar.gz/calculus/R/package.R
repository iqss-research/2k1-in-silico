#' @keywords internal
"_PACKAGE"

#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib calculus, .registration=TRUE 
NULL  
