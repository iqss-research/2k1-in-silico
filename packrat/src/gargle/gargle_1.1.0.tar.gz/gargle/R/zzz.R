.onLoad <- function(lib, pkg) { # nocov start
  cred_funs_set_default()
  invisible()
} # nocov end
