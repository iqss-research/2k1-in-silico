library(testthat)
library(googlesheets4)

test_check("googlesheets4")
