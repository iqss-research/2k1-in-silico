library(testthat)
library(htmlwidgets)

test_check("htmlwidgets")
