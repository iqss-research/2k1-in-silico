# ad responds to venue

    Code
      ad("gh")
    Output
      <sup>Created on `r Sys.Date()` by the [reprex package](https://reprex.tidyverse.org) (v`r utils::packageVersion("reprex")`)</sup>

---

    Code
      ad("r")
    Output
      Created on `r Sys.Date()` by the reprex package v`r utils::packageVersion("reprex")` https://reprex.tidyverse.org

