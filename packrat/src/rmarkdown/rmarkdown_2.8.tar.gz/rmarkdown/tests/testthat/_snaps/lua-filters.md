# latex-divs.lua works with PDF/latex

    \begin{custom} content  \end{custom}

---

    \begin{custom} content  \end{custom}

---

    \begin{custom} content  \end{custom}

