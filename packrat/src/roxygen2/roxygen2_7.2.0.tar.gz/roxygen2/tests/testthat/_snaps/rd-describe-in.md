# complains about bad usage

    [<text>:6] @describeIn must be used with an object

---

    [<text>:6] @describeIn can not be used with @name

---

    [<text>:6] @describeIn can not be used with @rdname

