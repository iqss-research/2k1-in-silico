# warn about unknown tags

    [<text>:2] @unknown is not a known tag

