## Variables of Interest

***
These selection boxes let you set the variables of the `iris` dataset used in the `kmeans` algorithm. Change the value from the drop-downs to see the effect on the graph to the right.

***
This helpfile has a different icon - this is set using the `icon` parameter to the `helper()` function.
You can also include mathematical formulae using the `withMathJax` argument to `observe_helpers()`
This allows for elements in your help such as:
$$\\alpha+\\beta$$
