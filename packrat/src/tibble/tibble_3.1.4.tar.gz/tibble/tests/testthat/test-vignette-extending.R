test_that("extending vignette", {
  test_galley("extending")
})
