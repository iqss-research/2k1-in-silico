test_that("numbers vignette", {
  test_galley("numbers")
})
